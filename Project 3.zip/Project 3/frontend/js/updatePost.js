//=========================update post===========================
const updatePost = async () => {
  try {
    const updatePostText = document.getElementById("updatePost-text");
    const updateText = updatePostText.value;
    const updatePostImage = document.getElementById("updatePost-image");
    const updateImage = updatePostImage.value;

    const targetPostId = localStorage.getItem("targetPostId");

    const updateData = {
      postText: updateText,
      postImageUrl: updateImage,
    };
    const res = await fetch(
      `http://localhost:5000/updatePost/${targetPostId}`,
      {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(updateData),
      }
    );

    const result = await res.json();
    return result;
  } catch (err) {
    console.error("Error while updating note:", err);
    throw err;
  } finally {
    localStorage.removeItem("targetPostId");
    window.location.href = "../post.html";
  }
};
const undoChanges = () => {
  localStorage.removeItem("targetPostId");
  window.location.href = "../post.html";
};
